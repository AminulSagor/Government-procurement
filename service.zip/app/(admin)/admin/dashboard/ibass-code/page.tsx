"use client";

import { useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";

import IbasHeader from "./_components/ibas-header";
import IbasTabs from "./_components/ibas-tabs";
import IbasFiltersBar from "./_components/ibas-filters-bar";
import ParentHeadsTable from "./_components/ibas-table-parent-heads";
import EconomicCodesTable from "./_components/ibas-table-economic-codes";
import IbasPagination from "./_components/ibas-pagination";
import NewCodeDialogController from "./_components/new-code-dialog/NewCodeDialogController";

import type {
  EconomicFiltersState,
  IBasTab,
  ParentFiltersState,
  ParentHeadItem,
} from "./_types/ibas-codes.types";

import { demoEconomicCodes } from "./_data/ibas-codes.demo";
import { getParentCodes } from "@/service/admin/code.service";
import { getApiErrorMessage } from "@/utils/api-error.message";

export default function IbasCodesPage() {
  const [tab, setTab] = useState<IBasTab>("parent");
  const [openNewCode, setOpenNewCode] = useState(false);

  const [parentRows, setParentRows] = useState<ParentHeadItem[]>([]);
  const [isParentLoading, setIsParentLoading] = useState(false);

  const [parentFilters, setParentFilters] = useState<ParentFiltersState>({
    q: "",
    status: "any",
  });

  const [economicFilters, setEconomicFilters] = useState<EconomicFiltersState>({
    q: "",
    type: "all",
    status: "any",
  });

  async function loadParentCodes() {
    try {
      setIsParentLoading(true);

      const parentCodes = await getParentCodes({
        page: 1,
        limit: 8,
      });

      const mappedRows: ParentHeadItem[] = parentCodes.map((item) => ({
        id: item.code,
        parentCode4: item.code,
        expenseCategoryBn: item.expenseCategoryBangla,
        expenseCategoryEnglish: item.expenseCategoryEnglish,
        totalMappedEconomicCodes: item.operationalCount,
        status: item.status ? "active" : "inactive",
      }));

      setParentRows(mappedRows);
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Failed to load parent codes"));
    } finally {
      setIsParentLoading(false);
    }
  }
  useEffect(() => {
    if (tab === "parent") {
      void loadParentCodes();
    }
  }, [tab]);

  const filteredParentRows = useMemo(() => {
    const q = parentFilters.q.trim().toLowerCase();

    return parentRows.filter((r) => {
      const okQ =
        !q ||
        r.parentCode4.includes(q) ||
        r.expenseCategoryBn.toLowerCase().includes(q) ||
        r.expenseCategoryEnglish.toLowerCase().includes(q);

      const okStatus =
        parentFilters.status === "any"
          ? true
          : r.status === parentFilters.status;

      return okQ && okStatus;
    });
  }, [parentRows, parentFilters]);

  const economicRows = useMemo(() => {
    const q = economicFilters.q.trim().toLowerCase();

    return demoEconomicCodes.filter((r) => {
      const okQ =
        !q ||
        r.economicCode7.includes(q) ||
        r.nameBn.toLowerCase().includes(q) ||
        r.nameEn.toLowerCase().includes(q) ||
        r.parentCode4.includes(q);

      const okType =
        economicFilters.type === "all" ? true : r.type === economicFilters.type;

      const okStatus =
        economicFilters.status === "any"
          ? true
          : r.status === economicFilters.status;

      return okQ && okType && okStatus;
    });
  }, [economicFilters]);

  return (
    <div className="space-y-7">
      <IbasHeader onOpenNewCode={() => setOpenNewCode(true)} />

      <IbasTabs value={tab} onChange={setTab} />

      <IbasFiltersBar
        tab={tab}
        parentState={parentFilters}
        economicState={economicFilters}
        onChangeParent={setParentFilters}
        onChangeEconomic={setEconomicFilters}
      />

      {tab === "parent" ? (
        isParentLoading ? (
          <div className="rounded-xl border border-border bg-white p-10 text-center text-sm text-[var(--color-medium-gray)]">
            Loading parent codes...
          </div>
        ) : (
          <ParentHeadsTable rows={filteredParentRows} />
        )
      ) : (
        <EconomicCodesTable rows={economicRows} />
      )}

      <IbasPagination
        leftText={
          tab === "parent"
            ? `Showing 1-${Math.min(8, filteredParentRows.length)} of ${filteredParentRows.length} categories`
            : `Showing 1-${Math.min(8, economicRows.length)} of ${economicRows.length} results`
        }
      />

      {openNewCode ? (
        <NewCodeDialogController
          open={openNewCode}
          onClose={() => {
            setOpenNewCode(false);

            if (tab === "parent") {
              void loadParentCodes();
            }
          }}
        />
      ) : null}
    </div>
  );
}