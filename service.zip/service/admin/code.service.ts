import { serviceClient } from "@/service/base/axios.client";
import type {
  CodeCreateResponse,
  GetParentCodesParams,
  OperationalCodeCreatePayload,
  ParentCodeCreatePayload,
  ParentCodeListItem,
  ParentCodesResponse,
} from "@/types/admin/code.types";

export const createParentCode = async (
  payload: ParentCodeCreatePayload,
): Promise<CodeCreateResponse> => {
  const response = await serviceClient.post<CodeCreateResponse>(
    "/codes/create",
    payload,
  );

  return response.data;
};

export const createOperationalCode = async (
  payload: OperationalCodeCreatePayload,
): Promise<CodeCreateResponse> => {
  const response = await serviceClient.post<CodeCreateResponse>(
    "/codes/create",
    payload,
  );

  return response.data;
};

export const getParentCodes = async (
  params?: GetParentCodesParams,
): Promise<ParentCodeListItem[]> => {
  const response = await serviceClient.get<ParentCodesResponse>("/codes", {
    params: {
      type: "parent",
      page: params?.page ?? 1,
      limit: params?.limit ?? 100,
      status:
        typeof params?.status === "boolean" ? String(params.status) : undefined,
    },
  });

  return response.data.data.data;
};
