export const service_URL = process.env.NEXT_PUBLIC_API_BASE_URL;
